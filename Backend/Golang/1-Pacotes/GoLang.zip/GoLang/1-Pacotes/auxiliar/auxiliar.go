package auxiliar

import "fmt"

// Escrever registra uma mensagem na tela
func Escrever() {
	fmt.Println("Escrendo do pacote auxiliar")
}
