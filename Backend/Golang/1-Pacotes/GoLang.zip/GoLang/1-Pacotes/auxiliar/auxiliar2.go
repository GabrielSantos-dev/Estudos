package auxiliar

import "fmt"

func escrever2() {
	fmt.Println("Escrever pela funcao escrever2")
	escrever2()
}
